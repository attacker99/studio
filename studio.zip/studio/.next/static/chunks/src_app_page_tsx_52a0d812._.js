(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_db7d0808._.js",
  "static/chunks/node_modules_f3061008._.js"
],
    source: "dynamic"
});
