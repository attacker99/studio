(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_89d76a3a._.js",
  "static/chunks/src_91b9e51f._.js"
],
    source: "dynamic"
});
